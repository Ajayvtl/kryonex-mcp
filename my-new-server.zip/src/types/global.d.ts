export {};

declare global {
  var __KRYONEX_EVENTBUS: any;
  var __KRYONEX_TASKQUEUE: any;
  var __KRYONEX_WORKFLOW: any;
  var __KRYONEX_TOOLRUNNER: any;
  var __KRYONEX_DB: any;
  var __KRYONEX_AGENTS: any;
}
