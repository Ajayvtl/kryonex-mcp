declare module "./system/eventBus.mjs" {
  export default class EventBus {
    constructor(opts?: { db?: any; semanticStore?: any });
    emitPersisted(name: string, payload?: any): Promise<void>;
    emit(name: string, payload?: any): boolean;
    on(event: string, listener: (...args: any[]) => void): this;
  }
}

declare module "./system/taskManager.mjs" {
  export default class TaskManager {
    constructor(opts?: { db?: any; eventBus?: any });
    loadFromDb(): Promise<void>;
    createTask(opts?: any): Promise<any>;
    updateTask(task: any): Promise<any>;
    getTask(id: string): any;
    listTasks(): any[];
    addStep(taskId: string, step?: any): Promise<any>;
    startStep(taskId: string, stepId: string): Promise<any>;
    completeStep(taskId: string, stepId: string, result?: any): Promise<any>;
    failStep(taskId: string, stepId: string, error?: any): Promise<any>;
    completeTask(id: string, result?: any): Promise<any>;
    failTask(id: string, error?: any): Promise<any>;
  }
}

declare module "./system/workflowEngine.mjs" {
  export default class WorkflowEngine {
    constructor(opts?: { taskManager?: any; eventBus?: any; db?: any; concurrency?: number });
    registerTask(task: any): any;
    addDependency(taskId: string, dependsOn: string): void;
    scheduleTask(taskId: string, fn: () => Promise<any>, opts?: { dependsOn?: string[]; retries?: number; timeoutMs?: number }): Promise<any>;
    runGraph(rootTaskId: string, steps: Array<any>, opts?: any): Promise<any>;
  }
}

declare module "./system/taskQueue.mjs" {
  export class InMemoryQueue {
    constructor();
    push(job: () => Promise<any>): void;
    length(): number;
  }
  export class RedisQueue {
    constructor(redisClient: any, queueName?: string);
    push(payload: any): Promise<void>;
    popBlocking(timeout?: number): Promise<any>;
  }
}

declare module "./system/toolRunner.mjs" {
  export default class ToolRunner {
    constructor(opts?: { taskManager?: any; eventBus?: any; db?: any; semanticStore?: any; validator?: any; rectifier?: any });
    call(toolHandlers: Record<string, Function>, toolName: string, args?: any, context?: any, options?: any): Promise<any>;
  }
}

declare module "./system/validator.mjs" {
  export default function createValidator(opts?: { ollamaTool?: any }): any;
}

declare module "./system/rectifier.mjs" {
  export default function createRectifier(opts?: { ollamaTool?: any }): any;
}
